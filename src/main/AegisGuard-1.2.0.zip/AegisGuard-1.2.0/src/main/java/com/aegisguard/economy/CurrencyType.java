package com.aegisguard.economy;

public enum CurrencyType {
    VAULT,
    EXP,
    LEVEL,
    ITEM
}
